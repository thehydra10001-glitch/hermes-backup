---
name: osint-investigation
description: "HERMES OSINT framework — multi-phase open-source intelligence investigation with 25 tools, structured reporting, and free API integrations"
version: 1.3
author: hermes-agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [osint, security, investigation, reconnaissance, social-media]
    category: security
---

# HERMES OSINT Investigation Framework

**Deploy target:** Kali Linux | **Python env:** `~/osint-env` | **25 tools installed**

## When to Use

- User asks to investigate a person, username, email, domain, IP, phone, or image using OSINT
- User provides a target and wants online presence, breach data, or digital footprint
- User wants a structured OSINT report with sourced findings
- Quick scan or deep investigation — both supported

## Reference Files

- `references/investigation-kuldipsinhmori-20260710.md` — Real investigation case study with tool performance metrics and pitfalls discovered
- `references/telegram-bot-api.md` — Sending messages to arbitrary Telegram chat IDs via bot API (for delivery)
- `references/github-api-recon.md` — GitHub API recon: user profiles, repos, identity correlation, pivot patterns
- `references/indian-phone-prefixes.md` — Indian mobile number prefix-to-operator/circle mapping (free lookup without APIs)
- `scripts/generate_osint_report.py` — fpdf2-based PDF report generator template (customize TARGET_NAME, IDENTITIES, PLATFORMS, etc.)

## Tool Path Setup

**Always activate venv before Python OSINT tools (maigret, holehe, socialscan, phoneinfoga, h8mail, sublist3r, metagoofil):**
```bash
source ~/osint-env/bin/activate
```

**System tools** (whois, nmap, dig, etc.) are in `/usr/bin/`. Sherlock is at `~/.local/bin/sherlock` (add `export PATH="$HOME/.local/bin:$PATH"` to `.bashrc` if needed).

---

## Quick Commands

| User says | Action |
|---|---|
| `INVESTIGATE: <target>` | Full OSINT, all 5 phases |
| `QUICK SCAN: <target>` | Phase 1 passive only, 5 min |
| `USERNAME: <handle>` | Sherlock + Maigret + WhatsMyName |
| `EMAIL: <email>` | Holehe + HIBP + breach check |
| `DOMAIN: <domain>` | DNS + WHOIS + subdomains + certs |
| `IP: <addr>` | Shodan + nmap + geolocation + ASN |
| `PHONE: <num>` | PhoneInfoga + NumVerify + TrueCaller |
| `IMAGE: <file/url>` | ExifTool + reverse image + geolocation |
| `REPORT` | Generate full report from session data |

---

## Tool Arsenal (25 tools)

### Username / Social Footprint
```bash
# Sherlock: fast (~10s), checks ~100 sites, finds ~8 results
sherlock <user> --print-found --timeout 10 --output /tmp/sherlock_<user>.txt

# Maigret: slower (~48s), checks 509 sites, finds ~11 results
# ⚠️ -J is JSON TYPE (simple/ndjson), NOT output file!
# Output goes to --folderoutput directory as report_<user>_simple.json
maigret <user> -J simple --folderoutput /tmp/maigret_out

# Run BOTH for comprehensive coverage — they complement each other
socialscan <user>
```

**Holehe output format:** `[+]` = found/registered, `[-]` = not found, `[x]` = error/unknown

### Email Intelligence
```bash
holehe <email>
h8mail -t <email>
theHarvester -d <domain> -b all
```

### Domain / DNS Recon
```bash
whois <domain> && dig <domain> ANY
dnsrecon -d <domain> && dnsenum <domain>
fierce -domain <domain>
sublist3r -d <domain>
amass enum -d <domain>
```

### Network / IP
```bash
nmap -sV -sC -O <target>
masscan <range> -p 1-65535
traceroute <target>
whatweb <url>
```

### Web App Recon
```bash
nikto -h <url>
gobuster dir -u <url> -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt
wafw00f <url>
```

### Metadata
```bash
exiftool <file>
metagoofil -d <domain> -t pdf,doc,xls -o /tmp/meta/
strings <binary>
```

### Phone Number Investigation
```bash
# PhoneInfoga (requires venv activation)
source ~/osint-env/bin/activate
cd ~/PhoneInfoga && python3 phoneinfoga.py -n +91XXXXXXXXXX

# NumVerify API (requires free API key from numverify.com)
curl -s "http://apilayer.net/api/validate?access_key=YOUR_KEY&number=XXXXXXXXXX&country_code=IN"

# Indian mobile prefix lookup (no API needed)
# First 4-5 digits determine operator and circle — see references/indian-phone-prefixes.md
```

**⚠️ PhoneInfoga syntax:** Use `-n <number>` NOT `scan -n <number>` — the `scan` subcommand doesn't exist in current version.

**Indian number format:** 10 digits, starts with 6/7/8/9. Prefix `+91` for international.

### Frameworks
```bash
recon-ng
spiderfoot --target <target>
```

### GitHub / Developer Recon (API, no auth needed)
```bash
# User profile — name, bio, repos, followers, creation date
curl -s "https://api.github.com/users/<username>" | python3 -m json.tool

# Repos list — names, languages, descriptions, last updated
curl -s "https://api.github.com/users/<username>/repos?per_page=30&sort=updated" | python3 -c "import sys,json; [print(f'{r[\"name\"]} | {r.get(\"language\",\"N/A\")} | {r.get(\"updated_at\",\"N/A\")}') for r in json.load(sys.stdin)]"
```
See `references/github-api-recon.md` for full patterns and field mapping.

---

## Free OSINT APIs

| Category | Tool | URL | Free Tier |
|---|---|---|---|
| Search | Shodan | https://shodan.io | 100/mo |
| Search | Censys | https://censys.io | 250/mo |
| Search | GreyNoise | https://viz.greynoise.io | Free |
| Search | URLScan | https://urlscan.io/api/v1/ | Free |
| Search | VirusTotal | https://virustotal.com/api/v3/ | 500/day |
| Dark Web | IntelligenceX | https://intelx.io | Limited |
| Email | HIBP | https://haveibeenpwned.com/api/v3/ | Free |
| Email | Hunter.io | https://hunter.io/api/v2/ | 25/mo |
| Email | EmailRep | https://emailrep.io/ | Free |
| Person | WhatsMyName | https://whatsmyname.app | Free |
| Person | GitHub API | https://api.github.com/users/<user> | 60/hr |
| DNS | crt.sh | https://crt.sh | Free |
| DNS | ViewDNS | https://viewdns.info/api/ | 1500/mo |
| DNS | SecurityTrails | https://securitytrails.com | 50/mo |
| DNS | Wayback | https://archive.org/wayback/ | Free |
| IP | IP-API | https://ip-api.com/json/ | 45/min |
| IP | ipinfo.io | https://ipinfo.io/ | 50k/mo |
| Phone | NumVerify | https://numverify.com/api | 100/mo |
| Dark Web | Ahmia | https://ahmia.fi | Free |
| Dark Web | BreachDirectory | https://breachdirectory.org | Free |

---

## 5-Phase Investigation Workflow

### Phase 0 — Mission Brief
```
TARGET:       [input]
TARGET TYPE:  [person / username / email / domain / IP / org / phone / image]
MISSION:      [what operator wants to find]
STARTED:      [timestamp UTC]
```

### Phase 1 — Passive Recon
- WHOIS / DNS records
- Historical snapshots (Wayback Machine)
- SSL certificate transparency (crt.sh)
- Public social profiles
- Search engine dorking (site:, filetype:, cache:, related:)
- Breach database checks

### Phase 2 — Active Enumeration
- Port scanning (nmap)
- Subdomain enumeration (sublist3r, amass, fierce)
- Directory brute-forcing (gobuster)
- Email harvesting (theHarvester)
- Username hunting (sherlock, maigret)
- Tech fingerprinting (whatweb, builtwith)

### Phase 3 — Correlation & Pivoting
```
email → breach check → accounts → social → phone → location
domain → subdomains → IPs → ASN → related → owner
username → platforms → bios → emails → real identity
```

### Phase 4 — Verification
- Cross-check every finding with 2+ independent sources
- Flag unverified data as `[UNVERIFIED]`

### Phase 5 — Report
Use structured report template with sections: Target Profile, Findings (Identity, Digital Footprint, Email, Network, Geolocation, Breach, Timeline), Pivot Map, Evidence Log, Analyst Notes, Tool Log.

---

## Sherlock Fix Protocol

If sherlock fails or hangs:
1. **Maigret** fallback: `maigret <user> -J simple --folderoutput /tmp/maigret_out`
2. **GitHub API** (if target is a developer): see `references/github-api-recon.md` — returns name, bio, repos, followers, creation date
3. **WhatsMyName API**: `curl -s "https://whatsmyname.app/api/search?q=<user>" | python3 -m json.tool`
4. **Manual verify**: instantusername.com, namechk.com

⚠️ **Both Sherlock AND Maigret can timeout** on Kali (60s+ hangs). If both fail, pivot to GitHub API + web_search immediately — don't retry tools that already timed out.

Only report sites confirmed by 2+ sources.

---

## ORCID Public API (no key needed)

For researcher verification, the ORCID public API works without authentication:
```bash
# Search by name
curl -s "https://pub.orcid.org/v3.0/search/?q=family-name:Mori+AND+given-names:Kuldipsinh" \
  -H "Accept: application/json"

# Get full record by ORCID iD
curl -s "https://pub.orcid.org/v3.0/0009-0008-3093-7095" \
  -H "Accept: application/json"
```
Response includes: name, keywords, biography, employments, educations, works (publications).
Cross-verify ORCID keywords against LinkedIn bio for identity confirmation.

## Breach Check Limitations (2026)

⚠️ All major breach APIs now require paid API keys:
- **HIBP** — requires `hibp-api-key` header (paid: https://haveibeenpwned.com/API/Key)
- **EmailRep** — unauthenticated API disabled; needs API key
- **BreachDirectory** — Cloudflare challenge blocks automated access

**Workaround:** Direct operator to manual browser check at https://haveibeenpwned.com
For automated checks, obtain a HIBP API key and store in `.env` as `HIBP_API_KEY`.

## PDF Report Generation

See `scripts/generate_osint_report.py` for a complete fpdf2-based PDF report template.
Key rules:
- Use ASCII fallback chars (`-`, `[OK]`) instead of Unicode symbols — Helvetica is Latin-1 only
- For Unicode content, use `pdf.add_font()` with TTF files
- Custom FPDF subclass with `header()`, `footer()`, `section_title()`, `table_row()` methods
- Save output to `~/.hermes/pastes/` for easy retrieval

## Pitfalls

- **PEP 668** — always `source ~/osint-env/bin/activate` before pip-installed tools (maigret, holehe, socialscan, phoneinfoga, h8mail, sublist3r, metagoofil)
- **Symlink setup** — after venv install, symlink tools to `~/.local/bin/` and add to PATH in `.bashrc`
- **Sherlock** — add `--timeout 10` to avoid hangs; use `--output` to save results
- **Sherlock+Maigret timeout** — BOTH can hang on Kali (60s+). Don't retry; pivot to GitHub API + web_search immediately
- **Maigret `-J` flag** — `-J` is JSON TYPE (simple/ndjson), NOT output file path! Use `--folderoutput /dir` for output directory. File is auto-named `report_<user>_simple.json`
- **Maigret errors** — 11% "Access denied" is normal; use `--cloudflare-bypass` if worse
- **Amass** — passive mode fast, active needs wordlists; use `-passive` for quick scans
- **Holehe** — needs valid email; returns false if service blocks probing
- **Gobuster** — use `-x` for extensions, `-t 50` for threads
- **web_extract** — DuckDuckGo backend can only search, NOT extract URLs. For URL content, set `web.extract_backend` to firecrawl, tavily, exa, or parallel
- **DOCX extraction** — Use `python-docx` for .docx files (parses actual structure, far better than OCR). Install: `pip install python-docx --break-system-packages`
- **Breach APIs** — HIBP, EmailRep, BreachDirectory all require API keys in 2026; fall back to manual browser check
- **fpdf2 Unicode** — Helvetica font is Latin-1 only; use ASCII fallbacks (`-`, `[OK]`) or add TTF font for Unicode
- **Evidence** — save tool output to `/tmp/` or `~/.hermes/pastes/` before session ends
- **Browser tools** — camofox may not be running; if `browser_navigate` fails, pivot to `curl` + `web_search`/`web_extract` for web content
- **Legal** — only publicly available OSINT; no unauthorized access; operator responsible for compliance

---

### Phone Lookup Limitations
- **PhoneInfoga urllib3 error** — `AttributeError: module 'urllib3.util.ssl_' has no attribute 'DEFAULT_CIPHERS'` on Python 3.12+/urllib3 2.x. Workaround: downgrade urllib3 to 1.26.x in venv (`pip install urllib3==1.26.18`)
- **NumVerify demo key** — returns `invalid_access_key`; must register free account at numverify.com
- **Web scraping phone sites** — Truecaller, IndiaTrace, Varic, FindAndTrace all use Cloudflare protection or require auth; curl-based approaches fail
- **Indian phone prefix analysis** — Free fallback method (no API needed): first 4-5 digits determine operator + circle. See `references/indian-phone-prefixes.md`

## Communication Style

- `[HERMES ACTIVATED]` — begin investigation
- `[HERMES REPORT COMPLETE]` — end investigation
- `► Running: <cmd>` → `✓ Result:` or `✗ Failed:`
- `↪️ Pivoting from [A] → [B]`
- `[HIGH/MED/LOW]` confidence on every finding
- `[FOUND: YYYY-MM-DD HH:MM UTC]` timestamp on data points

## Self-Improvement Debrief (after every session)
```
Tools worked:    [list]
Tools failed:    [list + reason]
APIs returned:   [list]
APIs failed:     [list + reason]
Data gaps:       [what was missing]
Next run:        [what to try]
```
